import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f = new File("data_main.csv");
		f.createNewFile();
		String s;
		Scanner sc = new Scanner(f);
	

		MyHashTable tab = new MyHashTable();
		
		String[] all = new String[73654];
		String[] temp = new String[73654];
		String[] temp1 = new String[73654];
		String[] temp2 = new String[73654];
		String[] temp3 = new String[73654];
		String[] number = new String[73653];
		String[] model = new String[73653];
		String[] capacity = new String[73653];
		String[] hours = new String[73653];
		int count = 0;
		
		while(sc.hasNextLine()) {
			
			s = sc.nextLine() +",";
			s = s.trim();
			//String[] names = s.split(",");
			all[count] = s;
			count++;
			
		}
		
		
		String result = String.join("", all);
		
		String[] entryArray;
		entryArray = result.split(",");
		
	    for(int i=0; i <(entryArray.length/4); i++) {
		    
			temp[i] = entryArray[4*i].trim();
			temp1[i] = entryArray[4*i+1].trim();
			temp2[i] = entryArray[4*i+2].trim();
			temp3[i] = entryArray[4*i+3].trim();
			
	}
	    
	    for(int i=0; i <(entryArray.length/4)-4; i++) {
		    
			temp[i] = entryArray[4*i].trim();
			temp1[i] = entryArray[4*i+1].trim();
			temp2[i] = entryArray[4*i+2].trim();
			temp3[i] = entryArray[4*i+3].trim();
			
	}
	    
	    
	    for(int i=0; i <number.length; i++) {    
	 		number[i] = temp[i+1];
	 		model[i] = temp1[i+1];
	 		capacity[i] = temp2[i+1];
	 		hours[i] = temp3[i+1];
	 		
	 }
	    double startTime;
	    double endTime;
	    
	    startTime = System.nanoTime();
	    for(int i=0; i <number.length; i++) {    
	    	HDTestData HD = new HDTestData(number[i], model[i],
	    	capacity[i], hours[i]);
	    	tab.put(HD.element(), HD);
	 		
	 }
	    endTime = System.nanoTime();
	    
	    System.out.println("Average time to insert into hash table " +(endTime-startTime)/number.length +" ns");
		
		File snum8 = new File("snum_8.csv");
		File snum500 = new File("snum_500.csv");
		File snum10k = new File("snum_10k.csv");
		File snum25k = new File("snum_25k.csv");
		File snum50k = new File("snum_50k.csv");
		File snum70k = new File("snum_70k.csv");
		snum8.createNewFile();
		snum500.createNewFile();
		Scanner sc1 = new Scanner(snum8);
		Scanner sc2 = new Scanner(snum500);
		Scanner sc3 = new Scanner(snum10k);
		Scanner sc4 = new Scanner(snum25k);
		Scanner sc5 = new Scanner(snum50k);
		Scanner sc6 = new Scanner(snum70k);
		
		String[] s8 = new String[8];
		String[] s500 = new String[500];
		String[] s10k = new String[10001];
		String[] s25k = new String[25001];
		String[] s50k = new String[50001];
		String[] s70k = new String[74500];
		
		int count1 =0;
		int c2 =0;
		int c3 =0;
		int c4 = 0;
		int c5 = 0;
		int c6 =0;
		//8 numbers
		while(sc1.hasNextLine()) {
			
			s = sc1.nextLine();
			s = s.trim();
			s8[count1] = s;
			count1++;	
		}
		
		while(sc2.hasNextLine()) {
			
			s = sc2.nextLine();
			s = s.trim();
			s500[c2] = s;
			c2++;	
		}
		
		while(sc3.hasNextLine()) {
			
			s = sc3.nextLine();
			s = s.trim();
			s10k[c3] = s;
			c3++;	
		}
		
		while(sc4.hasNextLine()) {
			
			s = sc4.nextLine();
			s = s.trim();
			s25k[c4] = s;
			c4++;	
		}
		
		while(sc5.hasNextLine()) {
			
			s = sc5.nextLine();
			s = s.trim();
			s50k[c5] = s;
			c5++;	
		}
		
		while(sc6.hasNextLine()) {
			
			s = sc6.nextLine();
			s = s.trim();
			s70k[c6] = s;
			c6++;	
		}
		
		
		
		

		int coun = 0;
		String[] model2 = new String[500];
		String[] model3 = new String[10001];
		String[] model4 = new String[25001];
		String[] model5 = new String[50000];
		for(int n =0; n <415; n ++) {
		String ss = search(s500[n], number);
		HDTestData t1 = tab.get(ss);
		model2[n] = t1.getModel();
		}
		
		sort(s500, model2, 0 , 499);
		sort(s10k, model3, 0, 10000);
		
		
		
		
		System.out.println("File to sort: snum_8.csv");
		
		//8
		String[] model1 = new String[8];
		String[] capacity1 = new String[8];
		String [] hours1 = new String[8];

		
		double startTime2;
		double endTime2;
		double totalTime2 = 0;
		
		//8
		for(int n =0; n<s8.length; n++) {
		String t = search(s8[n], number);
		startTime2 = System.nanoTime();
		HDTestData g1 = tab.get(t);
		endTime2 = System.nanoTime();
		totalTime2 += (endTime2- startTime2);
		model1[n]= g1.getModel();
		}
		int l =s8.length;
		sort(model1, s8, 0, l-1);
		
		for(int w =0; w<s8.length; w++) {
		if(w ==0) System.out.println("\nFirst four after sorting on model name");
		if(w==4) System.out.println("\nLast four after soring on model name");
		System.out.println("Serial Number " +s8[w] + " Model Name " +model1[w]);
		}
		
		


		
		
		
		
		
		
		
		System.out.println();
		
		
		double startTime3;
		double endTime3;
		double totalTime3 = 0;
		
		for(int e =0; e<s8.length; e++) {
		String t = search(s8[e], number);
		startTime3 = System.nanoTime();
		HDTestData g1 = tab.get(t);
		endTime3 = System.nanoTime();
		totalTime3 += (endTime3 - startTime3);
		capacity1[e]= g1.getCapacity();
		//System.out.println(capacity1[e]);
		}
		
		
		
		System.out.println();
		mergeSort(capacity1, s8);
		
		System.out.println();
		for(int q =0; q<s8.length; q++) {
			if(q ==0) System.out.println("\nFirst four after sorting on capacity");
			if(q==4) System.out.println("\nLast four after soring on capacity");
			System.out.println("Serial Number " +s8[q] + " Capacity " +capacity1[q]);
		}
		
		double startTime4;
		double endTime4;
		double totalTime4 = 0; 
		
		for(int h =0; h<s8.length; h++) {
		String t = search(s8[h], number);
		startTime4 = System.nanoTime();
		HDTestData g1 = tab.get(t);
		endTime4 = System.nanoTime();
		totalTime4 += (endTime4 - startTime4);
		hours1[h]= g1.getHours();
		}
		
		
		
		System.out.println();
		double timeSearch = (totalTime2+totalTime3+totalTime4);
		double avgTimeSearch = timeSearch/(s8.length *3);
		System.out.println(" Average time taken to search entries in my hash table: " +avgTimeSearch+ " ns");
		
		
		
		
		MinHeap min = new MinHeap(hours1, s8);
		
		min.minHeap();
		min.print();
		
		
		
		
		


		File snum70k2 = new File("snum_70k.csv");
		snum70k.createNewFile();
		Scanner sc70k = new Scanner(snum70k2);
		String s1;
		int count2 =0;
		String[] s75k = new String[74500];
		//8 numbers
		while(sc70k.hasNextLine()) {
			
			s1 = sc70k.nextLine();
			s1 = s1.trim();
			s75k[count1] = s1;
			count2++;	
		}
		
		int n= 10000000;
		String[] quickArray = new String[n];
		String[] mergeArray = new String[n];
		String[] heapArray = new String[n];
		
		String[] temparr = new String[n];
		for(int i=0; i <temparr.length; i++) {
			temparr[i] = "";
		}
		
		
		Random r = new Random();
		for(int d =0; d<n; d++) {
		int k=	r.nextInt(number.length);
		quickArray[d] = number[k];
		mergeArray[d] = number[k];
		heapArray[d] = number[k];
		}
		
		int m = 1;
		double startTime5;
		double endTime5;
		double totalTime5 = 0; 
		
		for(int i=0; i <m; i++) {
		startTime5 = System.nanoTime();
		sort(quickArray, temparr, 0, quickArray.length-1);
		endTime5 = System.nanoTime();
		totalTime5 += (endTime5- startTime5);
		}
		double avgTime5 = totalTime5/m;
		System.out.println("average time taken by quicksort on an array of size " +n+ " (calculated via " +m+ " sorts): \n" 
				+avgTime5 + " ns");
		for(int i=0; i <quickArray.length; i++) {
			//System.out.println(quickArray[i]);
		}
		
		double startTime6;
		double endTime6;
		double totalTime6 = 0; 
		for(int i=0; i <m; i++) {
		startTime6 = System.nanoTime();
		mergeSort(mergeArray, temparr);
		endTime6 = System.nanoTime();
		totalTime6 += (endTime6 - startTime6);
		}
		double avgTime6 = totalTime6/m;
		System.out.println("average time taken by merge sort on an array of size " +n+ " (calculated via " +m+ " sorts): \n" 
				+avgTime6 + " ns");
		
		for(int i=0; i <mergeArray.length; i++) {
			//System.out.println(mergeArray[i]);
		}
		
		double startTime7;
		double endTime7;
		double totalTime7 = 0; 
		MinHeap heap = new MinHeap(heapArray, temparr);
		
		for(int i=0; i <m; i++) {
		startTime7 = System.nanoTime();
		heap.minHeap();
		endTime7 = System.nanoTime();
		totalTime7 += (endTime7 - startTime7);
		}
		double avgTime7 = totalTime7/m;
		System.out.println("average time taken by heap sort on an array of size " +n+ " (calculated via " +m+ " sorts): \n" 
				+avgTime7 + " ns");
		//heap.print();
		
		
	}
 public static int QSort(String arr[], String arr2[], int low, int high)
 {
     String pivot = arr[high]; 
     int i = (low-1); 
     for (int j=low; j<high; j++)
     {
         if (arr[j].compareTo(pivot) <=0)
         {
             i++;

             String temp = arr[i];
             arr[i] = arr[j];
             arr[j] = temp;
             
             String temp2 = arr2[i];
             arr2[i] = arr2[j];
             arr2[j] = temp2;
         }
     }

     String temp = arr[i+1];
     arr[i+1] = arr[high];
     arr[high] = temp;
     
     String temp2 = arr2[i+1];
     arr2[i+1] = arr2[high];
     arr2[high] = temp2;

     return i+1;
 }


 public static void sort(String arr[], String arr2[], int low, int high)
 {
     if (low < high)
     {
         int p = QSort(arr, arr2, low, high);

         sort(arr, arr2, low, p-1);
         sort(arr, arr2, p+1, high);
     }
 }
 
 public static String search(String s,String[] array) {
	 for(int i=0; i<array.length; i++) {
		 if(s.compareTo(array[i])==0) {
			// System.out.println(i);
			 return array[i];
			 //return array[i];
		 }

	 }
	 
	 return null;
 }
 
 
 
	/**
	 * 
	 * @param array 
	 * takes in unsorted letter array 
	 * calls leftHalf and rightHalf method to split array into two halves
	 * call mergeSort for right and left array
	 * merge together left and right array into one
	 * keep repeating until array length is 1
	 */
	public static void mergeSort(String[] array, String[] array1) {
		if (array.length > 1) {
		String[] left = leftHalf(array);
		String [] right = rightHalf(array);
		String[] left1 = leftHalf(array1);
		String [] right1 = rightHalf(array1);
		mergeSort(left, left1);
		mergeSort(right, right1);
		
		merge(array, array1, left,right, left1, right1);
		}
	}
	
	/**
	 * 
	 * @param array
	 * @return left array
	 * 
	 * takes in array and puts left side of array into new array
	 * 
	 * 
	 */
	public static String[] leftHalf( String[] array) {
		
		int size = array.length / 2;
     String[] left = new String[size];
     for (int i = 0; i < size; i++) {
         left[i] = array[i];
     }
     return left;
	}
	
	/**
	 * 
	 * @param array
	 * @return right array
	 * 
	 * takes in array and puts the right side of array into a new array
	 * 
	 */
	public static String[] rightHalf(String[] array) {
     int leftSize = array.length / 2;
     int rightSize = array.length - leftSize;
     String[] right = new String[rightSize];
     for (int i = 0; i < rightSize; i++) {
         right[i] = array[i + leftSize];
     }
     return right;
 }
	
	/**
	 * 
	 * @param result
	 * @param left
	 * @param right
	 * 
	 * takes in left half and right half of array and full array
	 * compares each character of left and right array and places correct character in full array
	 * return sorted array
	 */
	public static void merge(String[] result, String[] result2, String[] left, String[] right, String[] left1, String[] right1) {
		int index1 = 0;   // index into left array
		int index2 = 0;   // index into right array

		for (int i = 0; i < result.length; i++) {
			if (index2 >= right.length || (index1 < left.length && 
				left[index1].compareTo(right[index2]) <=0 )) {
				result[i] = left[index1];    // take from left
				result2[i] = left1[index1];
				index1++;
			} else {
				result[i] = right[index2];   // take from right
				result2[i] = right1[index2];
				index2++;
}
}
	}

}