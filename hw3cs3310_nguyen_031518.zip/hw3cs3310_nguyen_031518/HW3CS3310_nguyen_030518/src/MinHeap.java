
public class MinHeap {

	private String[] array;
	private String[] array1;
	private int size;
	
	
	public MinHeap(String[] arr, String[] arr1) {
		this.array = arr;
		this.array1 = arr1;
		this.size = arr.length;
		
	}
	
	private int parent(int pos)
    {
        return pos / 2;
    }
 
    private int leftChild(int pos)
    {
        return (2 * pos);
    }
 
    private int rightChild(int pos)
    {
        return (2 * pos) + 1;
    }
 
    private boolean isLeaf(int pos)
    {
        if (pos >=  (size / 2)  &&  pos <= size)
        { 
            return true;
        }
        return false;
    }
    
    private void swap(int fpos, int spos)
    {
        String tmp;
        String tmp1;
        tmp = array[fpos];
        tmp1 = array1[fpos];
        array[fpos] = array[spos];
        array1[fpos] = array1[spos];
        array[spos] = tmp;
        array1[spos] = tmp1;
    }
	
    private void minHeapify(int pos)
    {
        if (!isLeaf(pos))
        { 
            if ( array[pos].compareTo(array[leftChild(pos)]) > 0 || array[pos].compareTo(array[rightChild(pos)]) >0)
            {
                if (array[leftChild(pos)].compareTo(array[rightChild(pos)]) <0)
                {
                    swap(pos, leftChild(pos));
                    minHeapify(leftChild(pos));
                }else
                {
                    swap(pos, rightChild(pos));
                    minHeapify(rightChild(pos));
                }
            }
        }
    }
	
    public void minHeap()
    {
        for (int pos = (size / 2); pos >= 1 ; pos--)
        {
            minHeapify(pos);
        }
    }
	
    public void print()
    {
		System.out.println();
		for(int q =0; q<array.length; q++) {
			if(q ==0) System.out.println("\nFirst four after sorting on hours");
			if(q==4) System.out.println("\nLast four after sorting on hours");
			if(q <=4 || q >= array.length-4) {
			System.out.println("Serial Number " +array[q] + " hours " +array1[q]);
			}
		}
    }
    
    public void print1()
    {
		System.out.println();
		for(int q =0; q<array.length; q++) {
			System.out.println(array[q]);
		}
    }

	
}
