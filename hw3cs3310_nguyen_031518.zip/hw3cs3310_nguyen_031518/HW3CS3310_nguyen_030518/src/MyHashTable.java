
public class MyHashTable {

	private MyLinkedList[] table = new MyLinkedList[10000];
	int n;
	
	public MyHashTable() {
		for(int i =0; i <10000; i++) {
			table[i] = new MyLinkedList();
		}
	}
	
	public int hash(String number) {	
		char arr[];
		arr = number.toCharArray();
		int xlength = number.length();
		int i;
		int sum;
		for (sum=0, i=0; i < number.length(); i++)
		sum += arr[i];
		sum = sum*13;
		if(sum >9999) {
			sum = sum%1000;
		}
		return sum;
	}
	
	public void put(String n, HDTestData test) {
		int h = hash(n);
		//table[h] = new MyLinkedList();
		//System.out.println(h);
		table[h].append(n, test);
	
	}
	
	public HDTestData get(String num) {
		int h = hash(num);
		if(table[h].size() == -1) {
			return null;
		}
		//System.out.println(table[h].size());
		for(int i =0; i <table[h].size() +1; i++) {
			table[h].moveToPos(i);
			if(table[h].getValue() == num) {
				//System.out.println("HELL YEAH its in " +h+ " at " +i); 
				return table[h].curr;
			}
		}
		
		HDTestData a = new HDTestData("0", "0", "0", "0");
		return a;
		
	}
	
	public HDTestData getModel(String num) {
		int h = hash(num);
		if(table[h].size() == -1) {
			return null;
		}
		//System.out.println(table[h].size());
		for(int i =0; i <table[h].size() +1; i++) {
			table[h].moveToPos(i);
			if(table[h].getValue() == num) {
			
				return table[h].curr;
			}
		}
		
		return null;
		
	}
	
	
	
	
}
